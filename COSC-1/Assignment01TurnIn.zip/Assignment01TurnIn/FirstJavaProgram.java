
//------------------------------------------------------
// Programmer: Justin Jewell
// Course: COSC 1336 Section 010
// Semester: 2021
// Assignment #: Assignment01a
// Due Date: September 8, 2021
//------------------------------------------------------
public class FirstJavaProgram
{
	public static void main(String[] args)
	{
		System.out.println("This is my first Java program!");
		System.out.println("");
		System.out.println("This program was written by Justin Jewell");
		System.out.println("End of program.");
	}
}
