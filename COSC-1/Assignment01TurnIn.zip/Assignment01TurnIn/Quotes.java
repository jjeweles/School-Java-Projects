//------------------------------------------------------
// Programmer: Justin Jewell
// Course: COSC 1336 Section 010
// Semester: 2021
// Assignment #: Assignment01b
// Due Date: September 8, 2021
//------------------------------------------------------

public class Quotes
{
	public static void main(String[] args)
	{
		System.out.println("To be,");
		System.out.println(" or not to be,");
		System.out.println(" that is the question.");
		System.out.println("");
		System.out.println("Or perhaps,");
		System.out.println(" I should be asking,");
		System.out.println(" some other question!");
		System.out.println("");
		System.out.println("This program was written by Justin Jewell");
		System.out.println("End of program.");
	}
}