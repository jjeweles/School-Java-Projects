public class NoEvenNumberException extends Exception {

	public NoEvenNumberException(String message) {
		super(message);
	}

} // end class NoEvenNumberException